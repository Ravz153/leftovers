package my.mysql_php_register_login;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Rahul on 3/4/2017.
 */

public class Donor extends AppCompatActivity{
    private Spinner spinnerFood,boxCount,boxSize,expiry;
    private RadioButton yes,no,location;
    private EditText etAddress;
    Button donate;
    private StringRequest request;
    private RequestQueue requestQueue;
    private static final String URL = "http://leftover.000webhostapp.com/donor.php";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    setContentView(R.layout.donor);
intialize();
setSpinners();

        requestQueue = Volley.newRequestQueue(this);
        Intent i = getIntent();
        final String userId= i.getStringExtra("ID");
        donate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            if(jsonObject.names().get(0).equals("success")){
                                Toast.makeText(getApplicationContext(),"SUCCESS! "+jsonObject.getString("success"),Toast.LENGTH_LONG).show();
                            }else {
                                Toast.makeText(getApplicationContext(), "Error" +jsonObject.getString("error"), Toast.LENGTH_SHORT).show();
                            }

                            Intent i;
                            i = new Intent(getApplicationContext(),LoginActivity.class);
                            startActivity(i);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String,String> hashMap = new HashMap<String, String>();
                       hashMap.put("userid",userId);
                        hashMap.put("name",spinnerFood.getSelectedItem().toString());
                        hashMap.put("count",boxCount.getSelectedItem().toString());
                        hashMap.put("size",boxSize.getSelectedItem().toString());
                        hashMap.put("expiry",expiry.getSelectedItem().toString());
                        if(yes.isChecked()){
                            hashMap.put("perishable","yes");
                        }else{
                            hashMap.put("perishable","no");
                        }
                        if(location.isChecked()) {
                            hashMap.put("location", "yes");
                        }else{
                            hashMap.put("location", "no");
                            hashMap.put("newAdd",etAddress.getText().toString());
                        }

                        return hashMap;
                    }
                };
                requestQueue.add(request);
            }
        });


    }

    private void setSpinners() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.food, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFood.setAdapter(adapter);
        adapter = ArrayAdapter.createFromResource(
                this, R.array.boxcount, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
boxCount.setAdapter(adapter);
        adapter = ArrayAdapter.createFromResource(
                this, R.array.boxsize, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        boxSize.setAdapter(adapter);
        adapter = ArrayAdapter.createFromResource(
                this, R.array.expiry, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        expiry.setAdapter(adapter);


    }

    private void intialize() {
    spinnerFood = (Spinner) findViewById(R.id.spinnerFood);
        boxCount = (Spinner)findViewById(R.id.spinnerBoxCount);
        boxSize=(Spinner) findViewById(R.id.spinnerBoxSize);
        expiry = (Spinner)findViewById(R.id.spinnerExpiry);
        yes = (RadioButton)findViewById(R.id.radioButtonYes);
        no = (RadioButton)findViewById(R.id.radioButtonNo);
        location = (RadioButton)findViewById(R.id.radioButtonAddress);
        donate=(Button)findViewById(R.id.buttonDonate);
        etAddress = (EditText) findViewById(R.id.editTextAdd);
    }
}
