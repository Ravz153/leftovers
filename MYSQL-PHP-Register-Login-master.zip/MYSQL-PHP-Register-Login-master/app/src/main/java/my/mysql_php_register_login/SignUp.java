package my.mysql_php_register_login;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Rahul on 3/4/2017.
 */

public class SignUp extends AppCompatActivity {
    private EditText name,email,password,address,phone;
    private Button signUp;
    private StringRequest request;
    private RequestQueue requestQueue;
    private static final String URL = "http://leftover.000webhostapp.com/signup.php";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        initialize();
        requestQueue = Volley.newRequestQueue(this);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            if(jsonObject.names().get(0).equals("success")){
                                Toast.makeText(getApplicationContext(),"SUCCESS "+jsonObject.getString("success"),Toast.LENGTH_LONG).show();
                                startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                            }else {
                                Toast.makeText(getApplicationContext(), "Error" +jsonObject.getString("error"), Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String,String> hashMap = new HashMap<String, String>();
                        hashMap.put("name",name.getText().toString());
                        hashMap.put("email",email.getText().toString());
                        hashMap.put("password",password.getText().toString());
                        hashMap.put("address",address.getText().toString());
                        hashMap.put("phone",phone.getText().toString());
                        hashMap.put("type","user");
                        return hashMap;
                    }
                };
                requestQueue.add(request);
            }
        });
    }

    private void initialize() {
        name=(EditText)findViewById(R.id.name);
        email=(EditText)findViewById(R.id.emailSignUp);
        password=(EditText)findViewById(R.id.passwordSignUp);
        address=(EditText)findViewById(R.id.address);
        phone=(EditText)findViewById(R.id.phone);
        signUp=(Button) findViewById(R.id.signUp);
    }
}
