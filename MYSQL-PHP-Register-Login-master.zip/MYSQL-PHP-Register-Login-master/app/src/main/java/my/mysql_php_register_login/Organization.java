package my.mysql_php_register_login;

import android.app.Activity;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Rahul on 3/5/2017.
 */

public class Organization extends AppCompatActivity {
    private static final String URL = "http://leftover.000webhostapp.com/organization.php";
    private static final String URLOrg = "http://leftover.000webhostapp.com/organizationLocation.php";
    private static final String URLfood = "http://leftover.000webhostapp.com/organizationFood.php";


    private ArrayList<HashMap<String, String>> myList ;
    ListView lv ;
    String orgLocation;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.organization);
        myList =  new ArrayList<>();
        lv=(ListView) findViewById(R.id.list_view_nearby);
        Intent i = getIntent();
        final String orgID = i.getStringExtra("ID");
        final RequestQueue requestqueue = Volley.newRequestQueue(this);

        StringRequest requestSt = new StringRequest(Request.Method.POST, URLOrg, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if(jsonObject.names().get(0).equals("success")){

                        orgLocation=jsonObject.getString("success");
                        Toast.makeText(getApplicationContext(),orgLocation,Toast.LENGTH_LONG).show();
                    }else {
                        Toast.makeText(getApplicationContext(), "Error" +jsonObject.getString("error"), Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> hashMap = new HashMap<String, String>();
hashMap.put("orgid",orgID);
                return hashMap;
            }
        };
        requestqueue.add(requestSt);
fillLV(-1);
    //    final double[] latLngOrg = {0.0,0.0};
lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        TextView tvItem = (TextView) view.findViewById(R.id.idItem);
        final String itemID = tvItem.getText().toString();

        final RequestQueue requestqueue = Volley.newRequestQueue(Organization.this);

        StringRequest requestSt = new StringRequest(Request.Method.POST, URLfood, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if(jsonObject.names().get(0).equals("success")){

                        Intent returnIntent = new Intent();
                        returnIntent.putExtra("result","Added Succesfully");
                        setResult(Activity.RESULT_OK,returnIntent);
                        finish();
                    }else {
                        Toast.makeText(getApplicationContext(), "Error" +jsonObject.getString("error"), Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> hashMap = new HashMap<String, String>();
                hashMap.put("orgid",orgID);
                hashMap.put("foodid",itemID);
                return hashMap;
            }
        };
        requestqueue.add(requestSt);
        fillLV(i);
          }
});
    }

    private void fillLV(final int pos) {
        ArrayList<String> values = new ArrayList<String>();
        values.clear();

        ArrayAdapter <String> adapter;
        adapter = new ArrayAdapter<String>(this, R.layout.list_item,android.R.id.text1, values);
        lv.setAdapter(adapter);
       final double[] latLngOrg = getLatLng("7790 McCallum Blvd");
       // final double[] latLngOrg = getLatLng(orgLocation);
        final JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {


                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        String id = jsonObject.getString("id");
                        String name = jsonObject.getString("name");
                        String count = jsonObject.getString("count");
                        String size = jsonObject.getString("size");
                        String expiry = jsonObject.getString("expdate");
                        String location = jsonObject.getString("location");
                        HashMap<String, String> listMap = new HashMap<>();
                        listMap.put("id",id);
                        listMap.put("name",name);
                        listMap.put("count",count);
                        listMap.put("size",size);
                        listMap.put("expiry",expiry);
                        listMap.put("location",location);

                        String distance = getDistance(location,latLngOrg);
                        listMap.put("distance",distance);
                        myList.add(listMap);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                Collections.sort(myList, new Comparator<Map<String, String>>() {
                    @Override
                    public int compare(Map<String, String> o1, Map<String, String> o2) {
                        return o1.get("distance").compareTo(o2.get("distance"));
                    }
                });
                if(pos!=-1){
                    myList.remove(pos);
                }
                ListAdapter adapter = new SimpleAdapter(getBaseContext(),myList,R.layout.list_item,new String[]{"id","name","count","size","expiry","location"}, new int[]{R.id.idItem,R.id.nameItem,R.id.countItem,R.id.sizeItem,R.id.expiryItem,R.id.locationItem});
                lv.setAdapter(adapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
            }
        });
        Volley.newRequestQueue(this).add(request);

    }

    private String getDistance(String location,double[] latLngOrg) {

        double[] latLong = getLatLng(location);
int R =6371;
        double dLat = deg2rad(latLngOrg[0]-latLong[0]);  // deg2rad below
        double dLon = deg2rad(latLngOrg[1]-latLngOrg[1]);
        double a =
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                        Math.cos(deg2rad(latLngOrg[0])) * Math.cos(deg2rad(latLong[0])) *
                                Math.sin(dLon/2) * Math.sin(dLon/2)
                ;
        double  c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double d = R * c; // Distance in km
        return Double.toString(d);
    }

    public double deg2rad(double deg) {
        return deg * (Math.PI/180);
    }
    public double[] getLatLng(String address){
        Geocoder coder = new Geocoder(this);
        double lat =0;
        double lng =0;

        List<Address> addresses;
        try {
            addresses = coder.getFromLocationName(address, 5);
            if (addresses == null) {
            }
            Address location = addresses.get(0);
            lat = location.getLatitude();
            lng = location.getLongitude();
        } catch (IOException e) {
            e.printStackTrace();
        }
        double[] array = new double[2];
        array[0]=lat;
        array[1]=lng;
        return(array);
    }
}